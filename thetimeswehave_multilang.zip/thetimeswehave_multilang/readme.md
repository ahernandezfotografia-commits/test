{\rtf1\ansi\ansicpg1252\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # The Times We Have \'97 Multilenguaje\
\
Este sitio soporta 3 idiomas:\
\
- Espa\'f1ol: `/index.html`\
- English: `/en/index.html`\
- Portugu\'eas (BR): `/pt/index.html`\
\
## Deploy en Netlify\
1. Sube este repo a GitHub.\
2. Con\'e9ctalo en Netlify (`publish directory = .`).\
3. Netlify servir\'e1 autom\'e1ticamente `/`, `/en/`, `/pt/`.\
\
## Edici\'f3n\
- Textos \uc0\u8594  editar cada `index.html` seg\'fan idioma.\
- Colores \uc0\u8594  `css/styles.css` (variables en `:root`).\
- Im\'e1genes \uc0\u8594  carpeta `/assets/`.\
}